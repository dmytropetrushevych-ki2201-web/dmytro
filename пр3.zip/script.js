const addButton = document.getElementById("addButton");
const itemInput = document.getElementById("itemInput");
const shoppingList = document.getElementById("shoppingList");

addButton.addEventListener("click", addItem);
itemInput.addEventListener("keypress", function(event) {
    if (event.key === "Enter") addItem();
});

function addItem() {
    const itemText = itemInput.value.trim();
    if (itemText === "") return;

    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = itemText;

    const editButton = document.createElement("button");
    editButton.textContent = "✏️";
    editButton.classList.add("edit-btn");
    editButton.onclick = () => editItem(span);

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "🗑️";
    deleteButton.classList.add("delete-btn");
    deleteButton.onclick = () => deleteItem(li);

    li.appendChild(span);
    li.appendChild(editButton);
    li.appendChild(deleteButton);
    shoppingList.appendChild(li);

    itemInput.value = "";
    itemInput.focus();
}

function deleteItem(item) {
    if (confirm("Ви дійсно хочете видалити цей елемент?")) {
        item.remove();
    }
}

function editItem(span) {
    const newText = prompt("Редагуйте елемент:", span.textContent);
    if (newText !== null && newText.trim() !== "") {
        span.textContent = newText.trim();
    }
}
