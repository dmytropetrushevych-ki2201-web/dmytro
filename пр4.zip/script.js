const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");
const showAll = document.getElementById("showAll");
const showActive = document.getElementById("showActive");
const showCompleted = document.getElementById("showCompleted");

let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

function renderTasks(filter = "all") {
  taskList.innerHTML = "";

  let filtered = tasks;
  if (filter === "active") filtered = tasks.filter(t => !t.completed);
  if (filter === "completed") filtered = tasks.filter(t => t.completed);

  filtered.forEach((task, index) => {
    const li = document.createElement("li");

    if (!task.completed) {
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.addEventListener("change", () => markCompleted(index));
      li.appendChild(checkbox);
    } else {
      li.classList.add("completed");
    }

    const span = document.createElement("span");
    span.textContent = task.text;
    span.classList.add("task-text");
    span.addEventListener("dblclick", () => editTask(index));
    li.appendChild(span);

    const date = document.createElement("span");
    date.classList.add("date");
    date.textContent = task.date;
    li.appendChild(date);

    const delBtn = document.createElement("button");
    delBtn.textContent = "✖";
    delBtn.classList.add("delete-btn");
    delBtn.addEventListener("click", () => deleteTask(index));
    li.appendChild(delBtn);

    taskList.appendChild(li);
  });
}

function addTask() {
  const text = taskInput.value.trim();
  if (text === "") return;

  const now = new Date();
  const formattedDate = now.toLocaleDateString("uk-UA") + ", " + now.toLocaleTimeString("uk-UA", {hour: "2-digit", minute: "2-digit"});

  tasks.unshift({
    text,
    completed: false,
    date: formattedDate
  });

  saveTasks();
  renderTasks();
  taskInput.value = "";
}

function deleteTask(index) {
  tasks.splice(index, 1);
  saveTasks();
  renderTasks();
}

function markCompleted(index) {
  tasks[index].completed = true;
  saveTasks();
  renderTasks();
}

function editTask(index) {
  const newText = prompt("Редагуйте завдання:", tasks[index].text);
  if (newText !== null && newText.trim() !== "") {
    tasks[index].text = newText.trim();
    saveTasks();
    renderTasks();
  }
}

taskInput.addEventListener("keypress", (e) => {
  if (e.key === "Enter") addTask();
});

showAll.addEventListener("click", () => renderTasks("all"));
showActive.addEventListener("click", () => renderTasks("active"));
showCompleted.addEventListener("click", () => renderTasks("completed"));

renderTasks();
